import 'package:flutter/material.dart';

class AppState {
  static ValueNotifier<bool> refreshChatList = ValueNotifier<bool>(false);
}
