from flask import Flask, request, jsonify
from google.cloud import firestore
from firebase_admin import auth, credentials, initialize_app
# Initialize Flask app
app = Flask(__name__)

# Initialize Firestore
db = firestore.Client.from_service_account_json('flask backend\serviceAccountKey.json')


@app.route('/get_username/<user_id>', methods=['GET'])
def get_username(user_id):
    try:
        user_ref = db.collection('users').document(user_id)
        user_doc = user_ref.get()
        
        if user_doc.exists:
            user_data = user_doc.to_dict()
            return jsonify({"username": user_data.get('username', ''), "lastUpdated": user_data.get('lastUsernameUpdate', None)}), 200
        else:
            return jsonify({"error": "User not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/update_username', methods=['POST'])
def update_username():
    try:
        data = request.json
        user_id = data['userID']
        new_username = data['username']

        # Check if the username already exists
        query = db.collection('users').where('username', '==', new_username).stream()
        if any(query):
            return jsonify({"error": "Username already exists"}), 400

        user_ref = db.collection('users').document(user_id)
        user_doc = user_ref.get()

        if user_doc.exists:
            user_data = user_doc.to_dict()
            last_updated = user_data.get('lastUsernameUpdate', None)

            if last_updated:
                from datetime import datetime, timezone
                last_updated = last_updated.replace(tzinfo=timezone.utc)
                current_time = datetime.now(timezone.utc)
                if (current_time - last_updated).days < 60:
                    return jsonify({"error": "Username can only be updated once every 2 months"}), 400

        # Update the username
        user_ref.update({
            'username': new_username,
            'lastUsernameUpdate': firestore.SERVER_TIMESTAMP
        })

        return jsonify({"message": "Username updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/change_password', methods=['POST'])
def change_password():
    try:
        # Get request data
        data = request.get_json()
        user_id = data['userID']
        current_password = data['currentPassword']
        new_password = data['newPassword']

        # Fetch the user document from Firestore
        user_ref = db.collection('users').document(user_id)
        user_doc = user_ref.get()

        if not user_doc.exists:
            return jsonify({'error': 'User not found.'}), 404

        user_data = user_doc.to_dict()
        stored_password = user_data['password']

        # Check if the current password matches the stored password
        if current_password != stored_password:
            return jsonify({'error': 'Current password is incorrect.'}), 400

        # Update the password in Firestore
        user_ref.update({'password': new_password})

        return jsonify({'message': 'Password updated successfully!'}), 200

    except Exception as e:
        return jsonify({'error': f"An error occurred: {str(e)}"}), 500

# Initialize Firebase Admin SDK
cred = credentials.Certificate('flask backend\serviceAccountKey.json')
initialize_app(cred)

@app.route('/update_phone_number', methods=['POST'])
def update_phone_number():
    try:
        # Get request data
        data = request.get_json()
        user_id = data['userId']
        phone_number = data['phoneNumber']

        # Validate phone number format (Optional)
        if not phone_number.isdigit() or len(phone_number) < 10 or len(phone_number) > 15:
            return jsonify({'error': 'Invalid phone number format'}), 400

        # Update the phone number in Firestore
        user_ref = db.collection('users').document(user_id)
        user_ref.update({'phoneNumber': phone_number})

        return jsonify({'message': 'Phone number updated successfully!'}), 200

    except Exception as e:
        return jsonify({'error': f"An error occurred: {str(e)}"}), 500


@app.route('/send_verification_email', methods=['POST'])
def send_verification_email():
    try:
        # Get request data
        data = request.get_json()
        email = data['email']

        # Send email verification using Firebase Authentication
        user = auth.get_user_by_email(email)
        auth.send_email_verification(user.uid)

        return jsonify({'message': 'Verification email sent successfully!'}), 200

    except Exception as e:
        return jsonify({'error': f"An error occurred: {str(e)}"}), 500
@app.route('/report_user', methods=['POST'])
def report_user():
    try:
        data = request.get_json()
        who_reported_id = data['whoReportedId']
        reported_user_id = data['reportedUserId']
        report_details = data['reportDetails']

        # Add report to Firestore
        report_ref = db.collection('reports').add({
            'whoReportedId': who_reported_id,
            'reportedUserId': reported_user_id,
            'reportDetails': report_details,
            'timestamp': firestore.SERVER_TIMESTAMP
        })

        return jsonify({'reportId': report_ref.id}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/block_user', methods=['POST'])
def block_user():
    try:
        data = request.get_json()
        current_user_id = data['currentUserId']
        blocked_user_id = data['blockedUserId']

        # Add blocked user to Firestore
        db.collection('users').document(current_user_id).collection('blockedUsers').document(blocked_user_id).set({
            'timestamp': firestore.SERVER_TIMESTAMP
        })

        return jsonify({'message': 'User blocked successfully'}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/unblock_user', methods=['POST'])
def unblock_user():
    try:
        data = request.get_json()
        current_user_id = data['currentUserId']
        blocked_user_id = data['blockedUserId']

        # Remove blocked user from Firestore
        db.collection('users').document(current_user_id).collection('blockedUsers').document(blocked_user_id).delete()

        return jsonify({'message': 'User unblocked successfully'}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/get_blocked_users/<user_id>', methods=['GET'])
def get_blocked_users(user_id):
    try:
        # Fetch blocked users synchronously
        blocked_users_ref = db.collection('users').document(user_id).collection('blockedUsers')
        blocked_users = blocked_users_ref.get()  # Use get() instead of stream()

        blocked_users_list = []
        for user in blocked_users:
            user_doc = db.collection('users').document(user.id).get()
            if user_doc.exists:
                user_data = user_doc.to_dict() or {}
                blocked_users_list.append({
                    'userId': user.id,
                    'fullName': user_data.get('fullName', 'Unknown'),
                    'username': user_data.get('username', 'Unknown')
                })

        return jsonify(blocked_users_list), 200

    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({'error': str(e)}), 400

if __name__ == "__main__":
    app.run(debug=True,host='0.0.0.0', port=5000)
